//NOTE. MANY THINGS THGAT ARE SUPPOSED TO BE PRINTED OUT ARE THERE, JUST SCROLL UP (GAME IS BADLY FORMATTED)
import java.io.*;
import java.util.*;
public class Driver{
    //:O
    public static int Mon_index = 0;
    public static int farm_index = 0;
    public static int pot_index = 0;
    public static int pot_amount = 0;
    public static boolean game = true;
    public static Object [][] grid = new Object[10][10];
    public static String[][] String_grid = new String[10][10];
    public static boolean one_once = false;
    public static boolean two_once = false;
    public static int monster_count = 0;
    public static int[] nevertouchx = new int [6];
    public static int[] nevertouchy = new int [6];
    public static int[] nevertouchfarmx = new int [2];
    public static int[] nevertouchfarmy = new int [2];
    public static Monster[] monsters = new Monster[6];
    public static Farmer[] farmers = new Farmer[2];
    public static Potion[] potions = new Potion[2];
    public static Hero hero = new Hero();   
    public static boolean pot = false;
    public static boolean farm = false;
    public static boolean mon = false;
    public static String dir;
    public static boolean norun = false;
    public static boolean ultimate_break = false;
    public static Scanner kbReader = new Scanner(System.in);
    public static boolean farm1_instance = false;
    public static boolean farm2_instance = false;
    public static boolean left_section = false;
    public static boolean up_section = false;
    public static boolean right_section = false;
    public static boolean down_section = false;
    public static boolean topleft = false;
    public static boolean topright = false;
    public static boolean bottomleft = false;
    public static boolean bottomright = false;
    public static boolean mon_dead = false;
    public static void main(String[] args){
        for (int i = 0; i < 6; i++){
            nevertouchx[i] = 100;
            nevertouchy[i] = 100;
        }
        for (int i = 0; i < 2; i++){
            nevertouchfarmx[i] = 100;
            nevertouchfarmy[i] = 100;
            
        }
        
        for (int i = 0; i < 6; i++){
            monsters[i] = new Monster();
        }
        for (int i = 0; i < 2; i++){
            farmers[i] = new Farmer();
        }
        for (int i = 0; i < 2; i++){
            potions[i] = new Potion(0);
        }
        Scanner kbReader = new Scanner(System.in);
       for (int i = 0; i < 10; i++){
            for (int j = 0; j < 10; j++){
                String_grid[i][j] = "XXXX";
            }
            
            
        }
        
     /////////////////////////////////////////////////////////////////
        grid[hero.getX()][hero.getY()] = hero;
        String_grid[hero.getX()][hero.getY()] = "HERO";
        
    
        //make mosnter
        
        for (int i = 0; i < 6; i++){
            int x = (int)(Math.random()*10);
            int y = (int)(Math.random()*10);
            
            monsters[i].setX(x);
            monsters[i].setY(y);  
            
            if (grid[monsters[i].getX()][monsters[i].getY()] == null){
                grid[monsters[i].getX()][monsters[i].getY()] = monsters[i];
                
            
            }else {
                i--;
            }
           
        }   
        //make farmers
        for (int i = 0; i < 2; i++){
            int x = (int)(Math.random()*10);
            int y = (int)(Math.random()*10);
            
            farmers[i].setX(x);
            farmers[i].setY(y);  
            
            if (grid[farmers[i].getX()][farmers[i].getY()] == null){
                grid[farmers[i].getX()][farmers[i].getY()] = farmers[i];
                
            
            }else {
                i--;
            }
           
        }   
        
        for (int i = 0; i < 2; i++){
            int x = (int)(Math.random()*10);
            int y = (int)(Math.random()*10);
            
            potions[i].setX(x);
            potions[i].setY(y);  
            
            if (grid[potions[i].getX()][potions[i].getY()] == null){
                grid[potions[i].getX()][potions[i].getY()] = potions[i];
                
            
            }else {
                i--;
            }
           
        }   
        
        
        printMap();
    while (game == true){
        mon_dead = false;
        left_section = false;
        up_section = false;
        right_section = false;
        down_section = false;
        topleft = false;
        topright = false;
        bottomleft = false;
        bottomright = false;
        
        if (hero.getY() == 0){
            left_section = true;
        }
        if (hero.getY() == 9){
            right_section = true;
        }
        if (hero.getX() == 0){
            up_section = true;
        }
        if (hero.getX() == 9){
            down_section = true;
        }
        if (hero.getX() == 9 && hero.getY() == 0){
            bottomleft = true;
            left_section = false;
            up_section = false;
            right_section = false;
            down_section = false;
        }
        if (hero.getX() == 0 && hero.getY() == 9){
            topright = true;
            left_section = false;
            up_section = false;
            right_section = false;
            down_section = false;
        }
        if (hero.getX() == 0 && hero.getY() == 0){
            topleft = true;
            left_section = false;
            up_section = false;
            right_section = false;
            down_section = false;
        }
        if (hero.getX() == 9 && hero.getY() == 9){
            bottomright = true;
            left_section = false;
            up_section = false;
            right_section = false;
            down_section = false;
        }
        if (left_section == true){
            checkPotions(1);
            checkFarmers(1);
            checkMonsters(1);
            
            
            
        }
        
        if (up_section == true){
           checkPotions(2);   

           checkFarmers(2);
            checkMonsters(2);                       
        }
        
        if (right_section == true){
           checkPotions(3); 
           checkFarmers(3);
           checkMonsters(3);
              
        }
        
        if (down_section == true){
           checkPotions(4);
            checkFarmers(4);
           checkMonsters(4);

        }
        
        if (bottomleft == true){
           checkPotions(5);
           checkFarmers(5);
           checkMonsters(5);


        }
        
        if (topleft == true){
           

           checkPotions(6);
           checkFarmers(6);        
            checkMonsters(6);


        }
            
        if (bottomright == true){
          
          
          checkPotions(7);
          checkFarmers(7);
          checkMonsters(7);
        }
        
        if (topright == true){
           checkPotions(8);
          checkFarmers(8);
          checkMonsters(8);
        }
        
        if (left_section == false && up_section == false && right_section == false && down_section == false && bottomleft == false && topleft == false && topright == false && bottomright == false){
          checkPotions(9);
          checkFarmers(9);
          checkMonsters(9);
        }
        if (monsters[Mon_index].Mon_health() <= 0 || ultimate_break == true){
            norun = false;
        }
         ultimate_break = false;
        if (hero.getHp() <= 0){
            game = false;
            norun = true;
            
        }
            
        if(norun == false){
            if (game == true){
            System.out.println("Enter direction (w, a, s, d): ");
            System.out.println("Type 'pot' if you wish to drink a potion: amount: " + pot_amount);
            
            dir = kbReader.nextLine();

            move(dir);
        }
       }
      
        
        if (game == true){
            for (int i = 0; i<100; i++){
                System.out.println("");
            }
            printMap();
        }
    }
}
public static void move(String dir){
            
            if (dir.equals("pot")){
                if (pot_amount > 0){
                    System.out.println("Potion used!");
                    hero.setHp(-100);  
                    pot_amount -=1;
                }else {
                    System.out.println("You don't have any potions!");
                }
                
            }else if (dir.equals("w")){
               hero.move(-1,0, nevertouchx, nevertouchy, nevertouchfarmx, nevertouchfarmy);
              
               
                    
            }else if (dir.equals("s")){
                hero.move(1,0, nevertouchx, nevertouchy, nevertouchfarmx, nevertouchfarmy);
              
            }else if (dir.equals("a")){
               hero.move(0,-1, nevertouchx, nevertouchy, nevertouchfarmx, nevertouchfarmy);
               
            }else if (dir.equals("d")){
                hero.move(0,1, nevertouchx, nevertouchy, nevertouchfarmx, nevertouchfarmy);
                
            }
            
            grid[hero.getPastX()][hero.getPastY()] = null;
            String_grid[hero.getPastX()][hero.getPastY()] = "XXXX";
            grid[hero.getX()][hero.getY()] = hero;
            String_grid[hero.getX()][hero.getY()] = "HERO";
        
           
            
    
}

    public static void printMap(){
 
        for(int i=0;i<10;i++){
            for(int j=0;j<10;j++) {
                    System.out.print(String_grid[i][j]+"   ");
            }
            System.out.println("");
            
            System.out.println("");
            
        }
        System.out.println("Hero's health: " + hero.getHp());
}

   

    public static void checkMonsters(int n){
            
            if (n == 1){
               
               
                if ((grid[hero.getX() + 1][hero.getY()]) instanceof Monster || (grid[hero.getX() - 1][hero.getY()]) instanceof Monster || (grid[hero.getX()][hero.getY()+1]instanceof Monster)){
                    
                    norun = true;
                    
                    
                
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX() + 1][hero.getY()]) == grid[monsters[i].getX()][monsters[i].getY()]){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                        
                    }
                }
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                        
                    }
                }
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX()][hero.getY() +1]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }  
                String_grid[monsters[Mon_index].getX()][monsters[Mon_index].getY()] = "MONS";
                System.out.println("Monster encountered!");
                printMap();
                while (monsters[Mon_index].Mon_health()>0){
                    
                    System.out.println("Would you like to attack or run"); 
                    String s = kbReader.nextLine(); 
                    hero_action(s);
                    monster_action();
                    if (ultimate_break == true){
                        break;                        
                    }
                }
                
               }
            }
            
            else if (n == 2){
                if ((grid[hero.getX() + 1][hero.getY()]) instanceof Monster || (grid[hero.getX()][hero.getY()+1]instanceof Monster || (grid[hero.getX()][hero.getY()-1] instanceof Monster))){
                    norun = true;
         
                    
                
                 for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX() + 1][hero.getY()]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX()][hero.getY()+1]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX()][hero.getY() -1]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }  
                String_grid[monsters[Mon_index].getX()][monsters[Mon_index].getY()] = "MONS";
                System.out.println("Monster encountered!");
                printMap();
                while (monsters[Mon_index].Mon_health()>0){
              
                    
                    System.out.println("Would you like to attack or run"); 
                    String s = kbReader.nextLine(); 
                    hero_action(s);
                    monster_action();
                    if (ultimate_break == true){
                        break;
                    }
                }
                
               }
            }
            
            else if (n == 3){
                if ((grid[hero.getX() + 1][hero.getY()]) instanceof Monster || (grid[hero.getX() - 1][hero.getY()]) instanceof Monster || (grid[hero.getX()][hero.getY()-1]instanceof Monster)){
                    norun = true;
     
                   
                
                 for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX() + 1][hero.getY()]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX()][hero.getY() -1]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }  
                String_grid[monsters[Mon_index].getX()][monsters[Mon_index].getY()] = "MONS";
                System.out.println("Monster encountered!");
                printMap();
                while (monsters[Mon_index].Mon_health()>0){
                    System.out.println("Would you like to attack or run"); 
                    String s = kbReader.nextLine(); 
                    hero_action(s);
                    monster_action();
                    if (ultimate_break == true){
                        break;                        
                    }
                }
               }
            }
            
            else if (n == 4){
                if ((grid[hero.getX() -1][hero.getY()]) instanceof Monster || (grid[hero.getX()][hero.getY()+1]instanceof Monster || (grid[hero.getX()][hero.getY()-1] instanceof Monster))){
                    norun = true;
                
                    
                 for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX()][hero.getY() -1]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX()][hero.getY() +1]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                String_grid[monsters[Mon_index].getX()][monsters[Mon_index].getY()] = "MONS";
                System.out.println("Monster encountered!");
                printMap();
                while (monsters[Mon_index].Mon_health()>0){
                    System.out.println("Would you like to attack or run"); 
                    String s = kbReader.nextLine(); 
                    hero_action(s);
                    monster_action();
                    if (ultimate_break == true){
                        break;                        
                    }
                }
               }
            }
            
            else if (n == 5){
                if ((grid[hero.getX() -1][hero.getY()]) instanceof Monster || (grid[hero.getX()][hero.getY()+1]instanceof Monster)){
                    norun = true;
     
                    
                
                 for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX()][hero.getY()+1]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                String_grid[monsters[Mon_index].getX()][monsters[Mon_index].getY()] = "MONS";
                System.out.println("Monster encountered!");
                printMap();
                while (monsters[Mon_index].Mon_health()>0){

                    
                    System.out.println("Would you like to attack or run"); 
                    String s = kbReader.nextLine(); 
                    hero_action(s);
                    monster_action();
                    if (ultimate_break == true){
                        break;                        
                    }
                }
               }
            }
            
            else if (n == 6){
                if ((grid[hero.getX() +1][hero.getY()]) instanceof Monster || (grid[hero.getX()][hero.getY()+1]instanceof Monster)){
                    norun = true;
                 
                   
                
                 for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX() + 1][hero.getY()]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX()][hero.getY()+1]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                String_grid[monsters[Mon_index].getX()][monsters[Mon_index].getY()] = "MONS";
                System.out.println("Monster encountered!");
                printMap();
                while (monsters[Mon_index].Mon_health()>0){
               
                    
                    System.out.println("Would you like to attack or run"); 
                    String s = kbReader.nextLine(); 
                    hero_action(s);
                    monster_action();
                    if (ultimate_break == true){
                        break;                        
                    }
                }
               }
            }
            
            else if (n == 7){
                if ((grid[hero.getX() -1][hero.getY()]) instanceof Monster || (grid[hero.getX()][hero.getY()-1]instanceof Monster)){
                    norun = true;
    
                   
                
                 for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX()][hero.getY()-1]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                String_grid[monsters[Mon_index].getX()][monsters[Mon_index].getY()] = "MONS";
                System.out.println("Monster encountered!");
                printMap();
                while (monsters[Mon_index].Mon_health()>0){
        
                    
                    System.out.println("Would you like to attack or run"); 
                    String s = kbReader.nextLine(); 
                    hero_action(s);
                    monster_action();
                    if (ultimate_break == true){
                        break;                        
                    }
                }
               }
            }
            
            else if (n == 8){
                if ((grid[hero.getX() + 1][hero.getY()]) instanceof Monster || (grid[hero.getX()][hero.getY()-1]instanceof Monster)){
                    norun = true;
                   
                    
                
                 for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX() + 1][hero.getY()]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX()][hero.getY()-1]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
             if (hero.getHp() <= 0){
                game = false;
                norun = true;
                ultimate_break = true;
            }
            String_grid[monsters[Mon_index].getX()][monsters[Mon_index].getY()] = "MONS";
            System.out.println("Monster encountered!");
            printMap();
            while (monsters[Mon_index].Mon_health()>0){

                 System.out.println("Would you like to attack or run"); 
                    String s = kbReader.nextLine(); 
                    hero_action(s);
                    monster_action();
                    if (ultimate_break == true){
                        break;                        
                    }
                }
               }
            }
            
            else if (n == 9){
                if ((grid[hero.getX() -1][hero.getY()]) instanceof Monster || (grid[hero.getX()][hero.getY()+1]instanceof Monster || (grid[hero.getX()+1][hero.getY()]instanceof Monster) || (grid[hero.getX()][hero.getY()-1]instanceof Monster ))){
                    norun = true;
                    
                    
           
                 for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX() + 1][hero.getY()]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX()][hero.getY() +1]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }  
                for (int i = 0; i < 6; i++){
                    if ((grid[hero.getX()][hero.getY() -1]) == grid[monsters[i].getX()][monsters[i].getY()] ){
                        System.out.println(monsters[i].toString());
                        Mon_index = i;
                        nevertouchx[i] = monsters[i].getX();
                        nevertouchy[i] = monsters[i].getY();
                    }
                }  
                String_grid[monsters[Mon_index].getX()][monsters[Mon_index].getY()] = "MONS";
                System.out.println("Monster encountered!");
                printMap();
                while (monsters[Mon_index].Mon_health()>0){
                    System.out.println("Would you like to attack or run"); 
                    String s = kbReader.nextLine(); 
                    hero_action(s);
                    monster_action();
                    if (ultimate_break == true){
                        break;                        
                    }
                }
               }
            }
    }
     public static void checkFarmers(int n){
  
           if (n == 1){
                
                if ((grid[hero.getX() + 1][hero.getY()]) instanceof Farmer || (grid[hero.getX() - 1][hero.getY()]) instanceof Farmer || (grid[hero.getX()][hero.getY()+1]instanceof Farmer)){
                    for (int i = 0; i < 2; i++){
                        if ((grid[hero.getX() + 1][hero.getY()]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                            
                            farm_index = i;
                            nevertouchfarmx[i] = farmers[i].getX();
                            nevertouchfarmy[i] = farmers[i].getY();
                        }
                    }
                    for (int i = 0; i < 2; i++){
                        if ((grid[hero.getX() - 1][hero.getY()]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                            
                            farm_index = i;
                            nevertouchfarmx[i] = farmers[i].getX();
                            nevertouchfarmy[i] = farmers[i].getY();
                        }
                    }
                    for (int i = 0; i < 2; i++){
                        if ((grid[hero.getX()][hero.getY() +1]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                            
                            farm_index = i;
                            nevertouchfarmx[i] = farmers[i].getX();
                            nevertouchfarmy[i] = farmers[i].getY();
                        }
                    }  
                    if(monster_count > 2 && one_once == false){
                     farm1_instance = true;                       
                    }
                if (monster_count > 4 && one_once == false){
                    farm2_instance = true;
                
                }
                if (farm1_instance == true){
                    if (farm_index == 0){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given bronze armor (reduces atk dmg by 1/3)");
                        hero.setArmor("bronze"); 
                        one_once = true;
                        farm1_instance = false;
                    }
                }else if (farm2_instance == true){
                    if (farm_index == 1){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given broadsword(atk 20-50)");
                        hero.setWeapon("Broadsword", 20, 50);   
                        two_once = true;
                        farm2_instance = false;
                    }
                }else {
                    String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                    System.out.println("Farmer near!");
                    System.out.println(farmers[farm_index].toString(farm_index));
                    printMap();
                }
                }
                   
           }
            
            else if (n == 2){
                if ((grid[hero.getX() + 1][hero.getY()]) instanceof Farmer || (grid[hero.getX()][hero.getY()+1]instanceof Farmer || (grid[hero.getX()][hero.getY()-1] instanceof Farmer))){
                    for (int i = 0; i < 2; i++){
                        if ((grid[hero.getX()][hero.getY() +1]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                            
                            farm_index = i;
                            nevertouchfarmx[i] = farmers[i].getX();
                            nevertouchfarmy[i] = farmers[i].getY();
                        }
                    }  
                    for (int i = 0; i < 2; i++){
                        if ((grid[hero.getX()][hero.getY() -1]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                            
                            farm_index = i;
                            nevertouchfarmx[i] = farmers[i].getX();
                            nevertouchfarmy[i] = farmers[i].getY();
                        }
                    }  
                    for (int i = 0; i < 2; i++){
                        if ((grid[hero.getX() + 1][hero.getY()]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                            
                            farm_index = i;
                            nevertouchfarmx[i] = farmers[i].getX();
                            nevertouchfarmy[i] = farmers[i].getY();
                        }
                    }
                    if(monster_count > 2 && one_once == false){
                     farm1_instance = true;                       
                    }
                if (monster_count > 4 && one_once == false){
                    farm2_instance = true;
                
                }
                if (farm1_instance == true){
                    if (farm_index == 0){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given bronze armor (reduces atk dmg by 1/3)");
                        hero.setArmor("bronze"); 
                        one_once = true;
                        farm1_instance = false;
                    }
                }else if (farm2_instance == true){
                    if (farm_index == 1){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given broadsword(atk 20-50)");
                        hero.setWeapon("Broadsword", 20, 50);   
                        two_once = true;
                        farm2_instance = false;
                    }
                }else {
                    String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                    System.out.println("Farmer near!");
                    System.out.println(farmers[farm_index].toString(farm_index));
                    printMap();
                }
               }
            }
            
            else if (n == 3){
                if ((grid[hero.getX() + 1][hero.getY()]) instanceof Farmer || (grid[hero.getX() - 1][hero.getY()]) instanceof Farmer || (grid[hero.getX()][hero.getY()-1]instanceof Farmer)){
                          for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() + 1][hero.getY()]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                        
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                        
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() -1]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                        
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }  
                if(monster_count > 2 && one_once == false){
                     farm1_instance = true;                       
                    }
                if (monster_count > 4 && one_once == false){
                    farm2_instance = true;
                
                }
                if (farm1_instance == true){
                    if (farm_index == 0){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given bronze armor (reduces atk dmg by 1/3)");
                        hero.setArmor("bronze"); 
                        one_once = true;
                        farm1_instance = false;
                    }
                }else if (farm2_instance == true){
                    if (farm_index == 1){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given broadsword(atk 20-50)");
                        hero.setWeapon("Broadsword", 20, 50);   
                        two_once = true;
                        farm2_instance = false;
                    }
                }else {
                    String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                    System.out.println("Farmer near!");
                    System.out.println(farmers[farm_index].toString(farm_index));
                    printMap();
                }
                
               }
            }
            
           else if (n == 4){
                if ((grid[hero.getX() -1][hero.getY()]) instanceof Farmer || (grid[hero.getX()][hero.getY()+1]instanceof Farmer || (grid[hero.getX()][hero.getY()-1] instanceof Farmer))){
                   for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[farmers[i].getX()][farmers[i].getY()] ){
               
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() +1]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                      
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }  
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() -1]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                       
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }
                if(monster_count > 2 && one_once == false){
                     farm1_instance = true;                       
                    }
                if (monster_count > 4 && one_once == false){
                    farm2_instance = true;
                
                }
                if (farm1_instance == true){
                    if (farm_index == 0){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given bronze armor (reduces atk dmg by 1/3)");
                        hero.setArmor("bronze"); 
                        one_once = true;
                        farm1_instance = false;
                    }
                }else if (farm2_instance == true){
                    if (farm_index == 1){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given broadsword(atk 20-50)");
                        hero.setWeapon("Broadsword", 20, 50);   
                        two_once = true;
                        farm2_instance = false;
                    }
                }else {
                    String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                    System.out.println("Farmer near!");
                    System.out.println(farmers[farm_index].toString(farm_index));
                    printMap();
                }
                
               }
            }
            
           else if (n == 5){
                if ((grid[hero.getX() -1][hero.getY()]) instanceof Farmer || (grid[hero.getX()][hero.getY()+1]instanceof Farmer)){
                     for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                        
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY()+1]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                        
                        
                    }
                }
                if(monster_count > 2 && one_once == false){
                     farm1_instance = true;                       
                    }
                if (monster_count > 4 && one_once == false){
                    farm2_instance = true;
                
                }
                if (farm1_instance == true){
                    if (farm_index == 0){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given bronze armor (reduces atk dmg by 1/3)");
                        hero.setArmor("bronze"); 
                        one_once = true;
                        farm1_instance = false;
                    }
                }else if (farm2_instance == true){
                    if (farm_index == 1){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given broadsword(atk 20-50)");
                        hero.setWeapon("Broadsword", 20, 50);   
                        two_once = true;
                        farm2_instance = false;
                    }
                }else {
                    String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                    System.out.println("Farmer near!");
                    System.out.println(farmers[farm_index].toString(farm_index));
                    printMap();
                }
               }
            }
            
           else if (n == 6){
                if ((grid[hero.getX() +1][hero.getY()]) instanceof Farmer || (grid[hero.getX()][hero.getY()+1]instanceof Farmer)){
                     for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() + 1][hero.getY()]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                        System.out.println(farmers[i].toString(i));
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY()+1]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                        System.out.println(farmers[i].toString(i));
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }
                if(monster_count > 2 && one_once == false){
                     farm1_instance = true;                       
                    }
                if (monster_count > 4 && one_once == false){
                    farm2_instance = true;
                
                }
                if (farm1_instance == true){
                    if (farm_index == 0){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given bronze armor (reduces atk dmg by 1/3)");
                        hero.setArmor("bronze"); 
                        one_once = true;
                        farm1_instance = false;
                    }
                }else if (farm2_instance == true){
                    if (farm_index == 1){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given broadsword(atk 20-50)");
                        hero.setWeapon("Broadsword", 20, 50);   
                        two_once = true;
                        farm2_instance = false;
                    }
                }else {
                    String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                    System.out.println("Farmer near!");
                    System.out.println(farmers[farm_index].toString(farm_index));
                    printMap();
                }
               }
            }
            
           else if (n == 7){
                if ((grid[hero.getX() -1][hero.getY()]) instanceof Farmer || (grid[hero.getX()][hero.getY()-1]instanceof Farmer)){
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                 
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }
                    for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() -1]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }  
                if(monster_count > 2 && one_once == false){
                     farm1_instance = true;                       
                    }
                if (monster_count > 4 && one_once == false){
                    farm2_instance = true;
                
                }
                if (farm1_instance == true){
                    if (farm_index == 0){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given bronze armor (reduces atk dmg by 1/3)");
                        hero.setArmor("bronze"); 
                        one_once = true;
                        farm1_instance = false;
                    }
                }else if (farm2_instance == true){
                    if (farm_index == 1){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given broadsword(atk 20-50)");
                        hero.setWeapon("Broadsword", 20, 50);   
                        two_once = true;
                        farm2_instance = false;
                    }
                }else {
                    String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                    System.out.println("Farmer near!");
                    System.out.println(farmers[farm_index].toString(farm_index));
                    printMap();
                }
               }
            }
            
           else if (n == 8){
                if ((grid[hero.getX() + 1][hero.getY()]) instanceof Farmer || (grid[hero.getX()][hero.getY()-1]instanceof Farmer)){
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() + 1][hero.getY()]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                       
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }
                 for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() -1]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                       
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                
                }
                if(monster_count > 2 && one_once == false){
                     farm1_instance = true;                       
                    }
                if (monster_count > 4 && one_once == false){
                    farm2_instance = true;
                
                }
                if (farm1_instance == true){
                    if (farm_index == 0){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given bronze armor (reduces atk dmg by 1/3)");
                        hero.setArmor("bronze"); 
                        one_once = true;
                        farm1_instance = false;
                    }
                }else if (farm2_instance == true){
                    if (farm_index == 1){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given broadsword(atk 20-50)");
                        hero.setWeapon("Broadsword", 20, 50);   
                        two_once = true;
                        farm2_instance = false;
                    }
                }else {
                    String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                    System.out.println("Farmer near!");
                    System.out.println(farmers[farm_index].toString(farm_index));
                    printMap();
                }
               }
            }
            
           else if (n == 9){
                if ((grid[hero.getX() -1][hero.getY()]) instanceof Farmer || (grid[hero.getX()][hero.getY()+1]instanceof Farmer || (grid[hero.getX()+1][hero.getY()]instanceof Farmer) || (grid[hero.getX()][hero.getY()-1]instanceof Farmer ))){
                      for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() + 1][hero.getY()]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                        
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[farmers[i].getX()][farmers[i].getY()] ){
              
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() +1]) == grid[farmers[i].getX()][farmers[i].getY()] ){
                        
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }  
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() -1]) == grid[farmers[i].getX()][farmers[i].getY()] ){
             
                        farm_index = i;
                        nevertouchfarmx[i] = farmers[i].getX();
                        nevertouchfarmy[i] = farmers[i].getY();
                    }
                }
                if(monster_count > 2 && one_once == false){
                     farm1_instance = true;                       
                    }
                if (monster_count > 4 && one_once == false){
                    farm2_instance = true;
                
                }
                if (farm1_instance == true){
                    if (farm_index == 0){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given bronze armor (reduces atk dmg by 1/3)");
                        hero.setArmor("bronze"); 
                        one_once = true;
                        farm1_instance = false;
                    }
                }else if (farm2_instance == true){
                    if (farm_index == 1){
                        String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                        System.out.println("Well done! Hero has been given broadsword(atk 20-50)");
                        hero.setWeapon("Broadsword", 20, 50);   
                        two_once = true;
                        farm2_instance = false;
                    }
                }else {
                    String_grid[farmers[farm_index].getX()][farmers[farm_index].getY()] = "FARM";
                    System.out.println("Farmer near!");
                    System.out.println(farmers[farm_index].toString(farm_index));
                    printMap();
                }
               }
            }
        
        
        }
        public static void checkPotions(int n){
  
           if (n == 1){
                   
                if ((grid[hero.getX() + 1][hero.getY()]) instanceof Potion || (grid[hero.getX() - 1][hero.getY()]) instanceof Potion || (grid[hero.getX()][hero.getY()+1]instanceof Potion)){
                        for (int i = 0; i < 2; i++){
                        if ((grid[hero.getX() + 1][hero.getY()]) == grid[potions[i].getX()][potions[i].getY()] ){
                            System.out.println(potions[i].toString());
                            pot_index = i;
                            pot_amount += 1;
                            hero.addPotion(pot_amount);
                        }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount += 1;
                        hero.addPotion(pot_amount);
                    }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() +1]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount += 1;
                        hero.addPotion(pot_amount);
                    }
                }  
                String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "POTS";
                System.out.println("Potion near!");
                printMap();
                String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "XXXX";
                grid[potions[pot_index].getX()][potions[pot_index].getY()] = null;
                
                
                   }
                }
            
           else if (n == 2){
                if ((grid[hero.getX() + 1][hero.getY()]) instanceof Potion || (grid[hero.getX()][hero.getY()+1]instanceof Potion || (grid[hero.getX()][hero.getY()-1] instanceof Potion))){
                    for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() +1]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount += 1;
                        hero.addPotion(pot_amount);
                    }
                }  
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() -1]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount += 1;
                        hero.addPotion(pot_amount);
                    }
                }  
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() + 1][hero.getY()]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount += 1;
                        hero.addPotion(pot_amount);
                    }
                }
                    
                    String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "POTS";
                    System.out.println("Potion near!");
                    printMap();
                    String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "XXXX";
                    grid[potions[pot_index].getX()][potions[pot_index].getY()] = null;
               }
            }
            
           else if (n == 3){
                if ((grid[hero.getX() + 1][hero.getY()]) instanceof Potion || (grid[hero.getX() - 1][hero.getY()]) instanceof Potion || (grid[hero.getX()][hero.getY()-1]instanceof Potion)){
                
                          for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() + 1][hero.getY()]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount += 1;
                        hero.addPotion(pot_amount);
                    }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount += 1;
                        hero.addPotion(pot_amount);
                    }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() -1]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount += 1;
                        hero.addPotion(pot_amount);
                    }
                }  
                     String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "POTS";
                    System.out.println("Potion near!");
                    printMap();
                    String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "XXXX";
                    grid[potions[pot_index].getX()][potions[pot_index].getY()] = null;
                
               }
            }
            
           else if (n == 4){
                if ((grid[hero.getX() -1][hero.getY()]) instanceof Potion || (grid[hero.getX()][hero.getY()+1]instanceof Potion || (grid[hero.getX()][hero.getY()-1] instanceof Potion))){
                      for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount += 1;
                        hero.addPotion(pot_amount);
                    }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() +1]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount += 1;
                        hero.addPotion(pot_amount);
                    }
                }  
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() -1]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount += 1;
                        hero.addPotion(pot_amount);
                    }
                }  
                    String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "POTS";
                    System.out.println("Potion near!");
                    printMap();
                    String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "XXXX";
                    grid[potions[pot_index].getX()][potions[pot_index].getY()] = null;
                
               }
            }
            
           else if (n == 5){
                if ((grid[hero.getX() -1][hero.getY()]) instanceof Potion || (grid[hero.getX()][hero.getY()+1]instanceof Potion)){
                    for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[potions[i].getX()][potions[i].getY()] ){
                        
                        pot_index = i;
                        System.out.println(potions[i].toString());
                        pot_amount += 1;
                        hero.addPotion(pot_amount);
                    }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY()+1]) == grid[potions[i].getX()][potions[i].getY()] ){
                        pot_index = i;
                        System.out.println(potions[i].toString());
                        pot_amount += 1;
                        hero.addPotion(pot_amount);
                    }
                }
                    String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "POTS";
                    System.out.println("Potion near!");
                    printMap();
                    String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "XXXX";
                    grid[potions[pot_index].getX()][potions[pot_index].getY()] = null;
               }
            }
            
           else if (n == 6){
                if ((grid[hero.getX() +1][hero.getY()]) instanceof Potion || (grid[hero.getX()][hero.getY()+1]instanceof Potion)){
                   for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() + 1][hero.getY()]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount +=1;
                        hero.addPotion(pot_amount);
                    }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY()+1]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount +=1;
                        hero.addPotion(pot_amount);
                    }
                }
                    String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "POTS";
                    System.out.println("Potion near!");
                    printMap();
                    String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "XXXX";
                    grid[potions[pot_index].getX()][potions[pot_index].getY()] = null;
                
               }
            }
            
           else if (n == 7){
                if ((grid[hero.getX() -1][hero.getY()]) instanceof Potion || (grid[hero.getX()][hero.getY()-1]instanceof Potion)){
                    for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount +=1;
                        hero.addPotion(pot_amount);
                    }
                }
                    for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() -1]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount +=1;
                        hero.addPotion(pot_amount);
                    }
                }  
                    String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "POTS";
                    System.out.println("Potion near!");
                    printMap();
                    String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "XXXX";
                    grid[potions[pot_index].getX()][potions[pot_index].getY()] = null;
                
               }
            }
            
           else if (n == 8){
                if ((grid[hero.getX() + 1][hero.getY()]) instanceof Potion || (grid[hero.getX()][hero.getY()-1]instanceof Potion)){
                    for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() + 1][hero.getY()]) == grid[farmers[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount +=1;
                        hero.addPotion(pot_amount);
                    }
                }
                 for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() -1]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount +=1;     
                        hero.addPotion(pot_amount);
                    }
                }  
                    String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "POTS";
                    System.out.println("Potion near!");
                    printMap();
                    String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "XXXX";
                    grid[potions[pot_index].getX()][potions[pot_index].getY()] = null;
                
               }
            }
            
           else if (n == 9){
                if ((grid[hero.getX() -1][hero.getY()]) instanceof Potion || (grid[hero.getX()][hero.getY()+1]instanceof Potion || (grid[hero.getX()+1][hero.getY()]instanceof Potion) || (grid[hero.getX()][hero.getY()-1]instanceof Potion ))){
                    for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() + 1][hero.getY()]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount +=1;
                        hero.addPotion(pot_amount);
                    }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX() - 1][hero.getY()]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount +=1;
                        hero.addPotion(pot_amount);
                    }
                }
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() +1]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount +=1;
                        hero.addPotion(pot_amount);
                    }
                }  
                for (int i = 0; i < 2; i++){
                    if ((grid[hero.getX()][hero.getY() -1]) == grid[potions[i].getX()][potions[i].getY()] ){
                        System.out.println(potions[i].toString());
                        pot_index = i;
                        pot_amount +=1;
                        hero.addPotion(pot_amount);
                    }
                }  
                    String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "POTS";
                    System.out.println("Potion found!");
                    printMap();
                    String_grid[potions[pot_index].getX()][potions[pot_index].getY()] = "XXXX";
                    grid[potions[pot_index].getX()][potions[pot_index].getY()] = null;
               }
            }
        
        
        }
        public static void hero_action(String s){
            int random = 0;
                if (s.equals("run")){
                    System.out.println("Where would you like to run away to? (WASD)");
                    String k = kbReader.nextLine();
                    
                if (monsters[Mon_index].Mon_spd() == 0){
                    random = (int)(Math.random()*100);
                    random+=1;
                    if (random <= 75){
                        System.out.println("Hero successfully runs away");
                        move(k);
                        ultimate_break = true;
                        
                        
                    }else {
                        System.out.println("Hero tries to run, but fails.");
                    }
                    
                }
                if (monsters[Mon_index].Mon_spd() == 1){
                    random = (int)(Math.random()*100);
                    random+=1;
                    if (random <= 50){
                        System.out.println("Hero successfully runs away");
                        move(k);
                        ultimate_break = true;
                    }else {
                        System.out.println("Hero tries to run, but fails.");
                    }
                    
                }
                if (monsters[Mon_index].Mon_spd() == 2){
                    random = (int)(Math.random()*100);
                    random+=1;
                    if (random <= 25){
                        System.out.println("Hero successfully runs away");
                        move(k);
                        ultimate_break = true;
                    }else {
                        System.out.println("Hero tries to run, but fails.");
                    }
                    
                }
                if (monsters[Mon_index].Mon_spd() == 3){
                    System.out.println("Hero cannot run away");
                    
                }
            }else if (s.equals("attack")){
                System.out.println("Hero attacks!");
                monsters[Mon_index].set_health((int)(Math.random()*(hero.getWeapon().max() - hero.getWeapon().min())+hero.getWeapon().min()));
                System.out.println("The Monster's health is now: " + (monsters[Mon_index].Mon_health()));
                
            }else {
                System.out.println("Please repeat that, you must say 'attack' or 'run' :)");
                
            }
            if (monsters[Mon_index].Mon_health() <= 0 || ultimate_break == true){
                    monster_count +=1;
                    System.out.println("MONSTER HAS DIED");
                    norun = false;
                    mon_dead = true;
                    if (monster_count == 6){
                        game = false;
                        for (int i = 0; i < 100; i++){
                            System.out.println("HERO HAS WON!!!!");
                        }
                        
                    }
            }
            if (hero.getHp() <= 0){
                game = false;
                norun = true;
                ultimate_break = true;   
            }
            if (hero.getY() == 0){
                left_section = true;
            }
            if (hero.getY() == 9){
                right_section = true;
            }
            if (hero.getX() == 0){
                up_section = true;
            }
            if (hero.getX() == 9){
                down_section = true;
            }
            if (hero.getX() == 9 && hero.getY() == 0){
                bottomleft = true;
                left_section = false;
                up_section = false;
                right_section = false;
                down_section = false;
            }
            if (hero.getX() == 0 && hero.getY() == 9){
                topright = true;
                left_section = false;
                up_section = false;
                right_section = false;
                down_section = false;
            }
            if (hero.getX() == 0 && hero.getY() == 0){
                topleft = true;
                left_section = false;
                up_section = false;
                right_section = false;
                down_section = false;
            }
            if (hero.getX() == 9 && hero.getY() == 9){
                bottomright = true;
                left_section = false;
                up_section = false;
                right_section = false;
                down_section = false;
            }
            if (game == true){
                
                printMap();
            }
        }
        
        public static void monster_action(){
            int random = 0;
            double atk = monsters[Mon_index].Mon_atk();
            if (mon_dead == false){
                System.out.println("Monster has dealt " + (atk * hero.defense()) + " damage"); 
                hero.setHp((double)(atk*hero.defense()));  
            }
            if (hero.getHp() <= 0){
                game = false;
                norun = true;
                ultimate_break = true;
                System.out.println("Hero has died.");
            }
                
           
        }
        

}