

public class Weapon{
    private String t;
    private static int min;
    private static int max;
    public Weapon(String type, int min_dmg, int max_dmg){
        this.t = type;
        this.min = min_dmg;
        this.max = max_dmg;
        
        
    }
    public String type(){
        return t;
    }
    public void setWeapon(String set){
        t = set;
    }
    public static int attack(){
        return (int)(Math.random()*(max-min)+min);
    }
    public static int min(){
        return min;
        
    }
   
    public static int max(){
        return max;
        
        
    }
}