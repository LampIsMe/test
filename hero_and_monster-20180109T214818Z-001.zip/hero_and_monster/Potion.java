
public class Potion{
    private int x = 0;
    private int y = 0;
    private int amount = 0;
    public Potion(int a){
       this.amount = a;
        
    }
    public int getX(){

        return x;
    }
    
    public int getY(){
     
        return y;
    }
    public void setX(int x){
        this.x = x;
    }
    public void setY(int y){
        this.y = y;
    }
    public String toString(){
        String s = "";
        s += ("What a mysterious powerful drink...this might be able to heal the hero");
        s += ("\n this potion is picked up by Hero");
        return s;
    }
}