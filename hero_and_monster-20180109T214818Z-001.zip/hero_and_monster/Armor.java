
public class Armor{
    private String t;
    
    public Armor(String type){
        this.t = type;
 
        
        
    }
    public void setArmor(String set){
        t = set;
    }
    public String type(){
        return t;
    }
    public double defense(){
        if (t.equals("bronze")){
            
            return (double)(1.0/3);
        }else {
            return 1;
        }
    }
    
}