
public class Monster{
    private int health;
    private int atk;
    private int spd;
    private int x = 0;
    private int y = 0;
  
    
    public Monster(){
        health = (int)(Math.random()*100);
        atk = (int)(Math.random()*30);
        spd = (int)(Math.random()*4);
        health +=1;
        atk +=1;
       
        
    }
    public int getX(){
        
        return x;
    }
    
    public int getY(){
        
        return y;
    }
    public int Mon_atk(){
        return atk;
    }
    public int Mon_spd(){
        return spd;
    }
    
    public int Mon_health(){
        return health;
    }
    
    public void set_health(int dmg){
        
        health -= dmg;
        
    }
    public void setX(int x){
        this.x = x;
    }
    public void setY(int y){
        this.y = y;
    }
    
    
    public String toString(){
        String s = null;
        s = "Monster's Health: " + Mon_health() + "\n" +
        "Monster's Speed: " + Mon_spd() + "\n"
        + "Monster's Attack: " + Mon_atk();
        return s;
    }
}