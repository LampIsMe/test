
public class Hero{
    private int x_pos;
    private int y_pos;
    private int health;
    private Weapon sword;
    private Armor breastplate;
    private Potion potion;
    private int past_x;
    private int past_y;
    private boolean check = true;
    public Hero(){
        x_pos = 9;
        y_pos = 0;
        health = 100;
        sword = new Weapon("dagger", 10, 30);
        breastplate = new Armor("none");
    }
    public double getHp(){
        return health;
        
    }
    public void setHp(double n){
        health -= n;
    }
    public int getX(){
        return x_pos;
    }
    public void setArmor(String s){
        
        breastplate = new Armor(s);
        
    }
    public void setWeapon(String s, int min, int max){
        sword = new Weapon(s, min, max);
    }
    public void addPotion(int a){
        potion = new Potion(a); 
    }
    public Weapon getWeapon(){
        return sword;
        
    }
    public double defense(){
     
        return breastplate.defense();
    }
    public int getY(){
        return y_pos;
    }
    public int getPastX(){
        return past_x;
    }
    
    public int getPastY(){
        return past_y;
    }
    public boolean checkHero(){
        return check;
    }
    public void move(int x, int y, int[] neverx, int[] nevery, int[] neverfarmx, int[] neverfarmy){
        check = true;
        if (((x_pos + x) == -1 || (x_pos + x) == 10 || (y_pos + y) == -1 || (y_pos + y) == 10)){
            
            System.out.println("Direction Invalid");
            check = false;
        }else {  
            for (int i = 0; i < 6; i++){
                
                if (((x_pos + x) == neverx[i]) && ((y_pos + y) == nevery[i])){
                        
                        System.out.println("Direction invalid");
                        check = false;
                }
            }
            for (int i = 0; i < 2; i++){
                
                if (((x_pos + x) == neverfarmx[i]) && ((y_pos + y) == neverfarmy[i])){
                       
                        System.out.println("Direction invalid");
                        check = false;
                }
            }
            if (check == true){
                    
                    x_pos += x;
                    y_pos += y;
                    check = true;
                    this.past_x = x_pos - x;
                    this.past_y = y_pos - y;
                
            }
            
        
        
        
    }
}
}
