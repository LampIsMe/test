
public class Farmer{
    private int x = 0;
    private int y = 0;
    public Farmer(){
       
        
    }
    public int getX(){
       
        return x;
    }
    
    public int getY(){
        
        return y;
    }
    
    public void setX(int x){
        this.x = x;
    }
    public void setY(int y){
        this.y = y;
    }
    public String toString(int index){
        String s = "";
        if (index == 0){
            s += ("My sheep is gone :( My family is gone :(\n" +
            "my bronze armor is not gone :) I hid it underground, only a true hero can receive this");
        }else if (index == 1){
            s += ("My cow is gone :( My family is gone :(\n"+
            "my broadsword (attack 20-50) is not gone :)");
            
        }
        
        return s;
    }
    
    
}